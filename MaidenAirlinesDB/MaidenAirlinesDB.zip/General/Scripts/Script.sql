SELECT count(ID) FROM orders WHERE orders.ID = 1
